Delusion = nil

TriggerEvent('Delusion:GetObject', function(obj) Delusion = obj end)

Delusion.Commands.Add("me", "Character interactions", {}, false, function(source, args)
	local text = table.concat(args, ' ')
	local Player = Delusion.Functions.GetPlayer(source)
	TriggerClientEvent('3dme:triggerDisplay', -1, text, source)
    TriggerEvent("delusion_log:server:CreateLog", "me", "Me", "white", "**"..GetPlayerName(source).."** (CitizenID: "..Player.PlayerData.citizenid.." | ID: "..source..")** " ..Player.PlayerData.charinfo.firstname.." "..Player.PlayerData.charinfo.lastname.. " **" ..text, false)
end)